
<!DOCTYPE html>
<html>
<head> 
    <title>Halaman Admin</title>
</head>
<body>
    
<h1>Daftar Mahasiswa</h1>

<table border="1" cellpadding="10" cellspacing="0">
    <tr>
        <th>No.</th>
        <th>Aksi</th>
        <th>Gambar</th>
        <th>NRP</th>
        <th>Nama</th>
        <th>Email</th>
        <th>Jurusan</th>
    </tr>

    <tr>
        <td>1</td>
        <td>
            <a href="">ubah</a> |
            <a href="">hapus</a>
        </td>
        <td><img.src="img/poto1.jpg" width="50"></td>
        <td>08323992</td>
        <td>Zahra</td>
        <td>ZahraFadilah@gmail.com</td>
        <td>rekayasa perangkat lunak & gim</td>
    </tr>
    <tr>
        <td>1</td>
        <td>
            <a href="">ubah</a> |
            <a href="">hapus</a>
        </td>
        <td><img.src="img/poto1.jpg" width="50"></td>
        <td>08323992</td>
        <td>Zahra</td>
        <td>ZahraFadilah@gmail.com</td>
        <td>rekayasa perangkat lunak & gim</td>
    </tr>
    <tr>
        <td>1</td>
        <td>
            <a href="">ubah</a> |
            <a href="">hapus</a>
        </td>
        <td><img.src="img/poto1.jpg" width="50"></td>
        <td>08323992</td>
        <td>Zahra</td>
        <td>ZahraFadilah@gmail.com</td>
        <td>rekayasa perangkat lunak & gim</td>
    </tr>





</table>

</body>
</html>